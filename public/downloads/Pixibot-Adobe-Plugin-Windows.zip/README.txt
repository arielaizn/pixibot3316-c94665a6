Pixibot Adobe Plugin - Windows Installation
============================================

INSTALLATION INSTRUCTIONS:
1. Right-click "INSTALL.bat"
2. Select "Run as Administrator"
3. Follow the on-screen instructions
4. Restart Premiere Pro or After Effects

MANUAL INSTALLATION (Alternative):
1. Copy the "com.pixibot.adobe.plugin" folder to:
   C:\Users\[YourUsername]\AppData\Roaming\Adobe\CEP\extensions\

2. Enable CEP debug mode (run as Administrator):
   reg add HKEY_CURRENT_USER\Software\Adobe\CSXS.10 /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add HKEY_CURRENT_USER\Software\Adobe\CSXS.11 /v PlayerDebugMode /t REG_SZ /d 1 /f

3. Restart Premiere Pro or After Effects

USAGE:
1. Open Premiere Pro or After Effects
2. Go to Window → Extensions → Pixibot
3. Sign in with your Pixibot account

REQUIREMENTS:
- Windows 10 or later
- Adobe Premiere Pro 2022+ or After Effects 2022+

SUPPORT:
Website: https://pixibot.app
Email: info@pixibot.app

UNINSTALL:
Delete the folder:
C:\Users\[YourUsername]\AppData\Roaming\Adobe\CEP\extensions\com.pixibot.adobe.plugin
