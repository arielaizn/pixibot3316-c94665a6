@echo off
echo ========================================
echo  Pixibot Adobe Plugin Installer
echo ========================================
echo.

:: Check for admin rights
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo ERROR: This installer requires Administrator privileges
    echo Please right-click and select "Run as Administrator"
    echo.
    pause
    exit /b 1
)

echo Installing Pixibot Adobe Plugin...
echo.

:: Get user's AppData directory
set APPDATA_DIR=%APPDATA%
set CEP_DIR=%APPDATA_DIR%\Adobe\CEP\extensions
set PLUGIN_DIR=%CEP_DIR%\com.pixibot.adobe.plugin

:: Create CEP directory if it doesn't exist
if not exist "%CEP_DIR%" (
    echo Creating CEP extensions directory...
    mkdir "%CEP_DIR%"
)

:: Remove old installation if exists
if exist "%PLUGIN_DIR%" (
    echo Removing old installation...
    rmdir /s /q "%PLUGIN_DIR%"
)

:: Copy plugin files
echo Copying plugin files...
xcopy /E /I /Y "%~dp0com.pixibot.adobe.plugin" "%PLUGIN_DIR%"

:: Enable CEP debug mode
echo Enabling CEP debug mode...
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

echo.
echo ========================================
echo  ✓ Installation Complete!
echo ========================================
echo.
echo To use the plugin:
echo 1. Restart Premiere Pro or After Effects
echo 2. Go to Window ^> Extensions ^> Pixibot
echo 3. Sign in with your Pixibot account
echo.
echo Installation location:
echo %PLUGIN_DIR%
echo.
pause
