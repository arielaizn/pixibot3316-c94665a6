/**
 * Pixibot ExtendScript for Adobe Premiere Pro
 * Provides automation functions for importing and editing
 */

// Test function
function helloWorld() {
  return JSON.stringify({ message: "Hello from Premiere Pro!", version: app.version });
}

/**
 * Import files to Premiere Pro
 * @param {string} filesJson - JSON string of files array
 * @param {string} binName - Name of bin to create
 * @returns {string} JSON result
 */
function importFilesToPremiere(filesJson, binName) {
  try {
    var files = JSON.parse(filesJson);
    var project = app.project;

    // Create new bin
    var bin = project.rootItem.createBin(binName);

    // Import each file
    var results = [];
    for (var i = 0; i < files.length; i++) {
      try {
        project.importFiles([files[i].localPath], true, bin, false);
        results.push({ name: files[i].name, success: true });
      } catch (err) {
        results.push({ name: files[i].name, success: false, error: err.toString() });
      }
    }

    return JSON.stringify({ success: true, imported: results, binName: binName });
  } catch (err) {
    return JSON.stringify({ success: false, error: err.toString() });
  }
}

/**
 * Add video clips to timeline
 * @param {string} videoFilesJson - JSON string of video file paths
 * @returns {string} JSON result
 */
function addClipsToTimeline(videoFilesJson) {
  try {
    var videoFiles = JSON.parse(videoFilesJson);
    var sequence = app.project.activeSequence;

    if (!sequence) {
      return JSON.stringify({ success: false, error: 'No active sequence' });
    }

    var track = sequence.videoTracks[0];
    var currentTime = sequence.getPlayerPosition();

    for (var i = 0; i < videoFiles.length; i++) {
      var projectItem = findProjectItemByPath(videoFiles[i]);
      if (projectItem) {
        track.insertClip(projectItem, currentTime.seconds);
        currentTime.seconds += projectItem.getOutPoint().seconds;
      }
    }

    return JSON.stringify({ success: true });
  } catch (err) {
    return JSON.stringify({ success: false, error: err.toString() });
  }
}

/**
 * Find project item by file path
 */
function findProjectItemByPath(path) {
  var items = app.project.rootItem.children;
  for (var i = 0; i < items.numItems; i++) {
    var item = items[i];
    try {
      if (item.getMediaPath() === path) {
        return item;
      }
    } catch (e) {}
  }
  return null;
}

/**
 * Execute Edit Agent command
 * @param {string} commandJson - JSON command object
 * @returns {string} JSON result
 */
function executeEditCommand(commandJson) {
  try {
    var command = JSON.parse(commandJson);

    switch (command.type) {
      case 'add_text':
        return addTextOverlay(command.payload);
      case 'trim_clip':
        return trimClip(command.payload);
      case 'add_effect':
        return addEffect(command.payload);
      case 'cut':
        return makeCut(command.payload);
      case 'autonomous':
        return executeAutonomous(command.payload);
      default:
        return JSON.stringify({ success: false, error: 'Unknown command: ' + command.type });
    }
  } catch (err) {
    return JSON.stringify({ success: false, error: err.toString() });
  }
}

function addTextOverlay(params) {
  try {
    var sequence = app.project.activeSequence;
    if (!sequence) {
      return JSON.stringify({ success: false, error: 'No active sequence' });
    }

    // Create essential graphics title
    var graphicsItem = app.project.rootItem.createTitle(params.text || 'Text');

    // Insert on video track 2 (overlay track)
    if (sequence.videoTracks.numTracks > 1) {
      var track = sequence.videoTracks[1];
      track.insertClip(graphicsItem, params.time || 0);
    } else {
      var track = sequence.videoTracks[0];
      track.insertClip(graphicsItem, params.time || 0);
    }

    return JSON.stringify({ success: true, message: 'Text added: ' + params.text });
  } catch (err) {
    return JSON.stringify({ success: false, error: err.toString() });
  }
}

function trimClip(params) {
  try {
    var sequence = app.project.activeSequence;
    var track = sequence.videoTracks[0];
    var clip = track.clips[params.clipIndex || 0];

    if (!clip) {
      return JSON.stringify({ success: false, error: 'Clip not found' });
    }

    if (typeof params.startTime !== 'undefined') {
      clip.setInPoint(params.startTime, 4);
    }
    if (typeof params.endTime !== 'undefined') {
      clip.setOutPoint(params.endTime, 4);
    }

    return JSON.stringify({ success: true, message: 'Clip trimmed' });
  } catch (err) {
    return JSON.stringify({ success: false, error: err.toString() });
  }
}

function makeCut(params) {
  try {
    var sequence = app.project.activeSequence;
    sequence.getPlayerPosition().seconds = params.time;

    // Use razor tool at current position
    var track = sequence.videoTracks[0];
    for (var i = 0; i < track.clips.numItems; i++) {
      var clip = track.clips[i];
      if (clip.start.seconds <= params.time && clip.end.seconds > params.time) {
        // Create a cut
        app.project.activeSequence.razor(params.time);
        break;
      }
    }

    return JSON.stringify({ success: true, message: 'Cut made at ' + params.time + 's' });
  } catch (err) {
    return JSON.stringify({ success: false, error: err.toString() });
  }
}

function addEffect(params) {
  try {
    var sequence = app.project.activeSequence;
    var clip = sequence.videoTracks[0].clips[params.clipIndex || 0];

    if (!clip) {
      return JSON.stringify({ success: false, error: 'Clip not found' });
    }

    // Add effect (example: Gaussian Blur)
    var effectName = params.effect || 'Gaussian Blur';
    var components = app.getVideoEffectList();

    for (var i = 0; i < components.length; i++) {
      if (components[i].displayName.toLowerCase().indexOf(effectName.toLowerCase()) !== -1) {
        clip.components.addComponent(components[i]);
        return JSON.stringify({ success: true, message: effectName + ' effect added' });
      }
    }

    return JSON.stringify({ success: false, error: 'Effect not found: ' + effectName });
  } catch (err) {
    return JSON.stringify({ success: false, error: err.toString() });
  }
}

function executeAutonomous(params) {
  try {
    var results = [];
    for (var i = 0; i < params.steps.length; i++) {
      var step = params.steps[i];
      var result = executeEditCommand(JSON.stringify(step));
      results.push(JSON.parse(result));
    }

    return JSON.stringify({ success: true, results: results, message: 'Autonomous editing completed' });
  } catch (err) {
    return JSON.stringify({ success: false, error: err.toString() });
  }
}
